var Gpio = require('onoff').Gpio;
var led = new Gpio(18, 'out');
led.writeSync(0);
